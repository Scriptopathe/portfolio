/**
 * 
 */
/**
 * @author seydoux
 *
 */
package fr.irit.sparql.Proxy;