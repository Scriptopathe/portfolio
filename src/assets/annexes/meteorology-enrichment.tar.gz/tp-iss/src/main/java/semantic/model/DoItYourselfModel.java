package semantic.model;

import java.util.HashMap;

import org.junit.Assert;

// import com.github.andrewoma.dexx.collection.HashMap;

public class DoItYourselfModel implements IModelFunctions
{
	static int lulz = 0;
	IConvenienceInterface model;
	HashMap<String, String> instantUris;
	HashMap<String, String> instantEntities;
	
	public DoItYourselfModel(IConvenienceInterface m) {
		this.model = m;
		this.instantEntities = new HashMap<String, String>();
		this.instantUris = new HashMap<String, String>();
	}

	@Override
	public String createPlace(String name) {
		String typeUri = this.model.getEntityURI("Lieu").get(0);
		String uri = this.model.createInstance(name, typeUri);
		model.listLabels(uri).add(name);
		return uri;
	}

	@Override
	public String createInstant(TimestampEntity instant) {
		// try to get cached value
		if(this.instantUris.containsKey(instant.timestamp)) {
			return this.instantUris.get(instant.timestamp);
		}
		
		String instantTypeUri = this.model.getEntityURI("Instant").get(0);
		// or create a new one
		String instance = model.createInstance("Instant" + lulz++, instantTypeUri);
		
		model.addDataPropertyToIndividual(instance, 
				model.getEntityURI("a pour timestamp").get(0), 
				instant.timestamp);
		
		this.instantUris.put(instant.timestamp, instance);
		this.instantEntities.put(instance, instant.timestamp);
		
		return instance;
	}

	@Override
	public String getInstantURI(TimestampEntity instant) {
		return instantUris.get(instant.timestamp);
	}

	@Override
	public String getInstantTimestamp(String instantURI)
	{
		return instantEntities.get(instantURI);
	}

	@Override
	public String createObs(String value, String paramURI, String instantURI) {
		String obsType = model.getEntityURI("Observation").get(0);
		String uri = model.createInstance("Obs" + lulz++, obsType);
		model.addDataPropertyToIndividual(uri, model.getEntityURI("a pour valeur").get(0), value);
		model.addObjectPropertyToIndividual(uri, model.getEntityURI("a pour date").get(0), instantURI);
		String sensorUri = model.whichSensorDidIt(this.getInstantTimestamp(instantURI), 
				paramURI);
		model.addObservationToSensor(uri, sensorUri);
		return uri;
	}
}
