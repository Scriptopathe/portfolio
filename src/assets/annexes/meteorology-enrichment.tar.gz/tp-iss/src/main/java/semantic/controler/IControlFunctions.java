package semantic.controler;

import java.util.List;

import semantic.model.ObservationEntity;

public interface IControlFunctions 
{
	public void instantiateObservations(List<ObservationEntity> obsList, String phenomenonURI);
}
