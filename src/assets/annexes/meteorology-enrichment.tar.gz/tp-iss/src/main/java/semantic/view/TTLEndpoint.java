package semantic.view;

public class TTLEndpoint
{

}
